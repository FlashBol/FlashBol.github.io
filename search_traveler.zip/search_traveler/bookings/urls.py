from django.urls import path
from . import views


app_name = 'bookings'

urlpatterns = [
    path('trip/<int:trip_pk>/create/', views.create_booking, name='create_booking'),
    path('trip/<int:trip_pk>/', views.trip_bookings, name='trip_bookings'),
    path(
        'trip/<int:trip_pk>/booking/<int:booking_pk>/status/<str:status>/',
        views.update_booking_status,
        name='update_booking_status'
    ),
    path('<int:pk>/cancel/', views.cancel_my_booking, name='cancel_my_booking'),
    path('<int:pk>/success/', views.booking_success, name='booking_success'),
]