from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone

from accounts.models import UserProfile
from trips.models import Trip
from .forms import BookingForm
from .models import Booking


def user_can_book(user):
    profile, created = UserProfile.objects.get_or_create(user=user)
    return profile.role in [
        UserProfile.ROLE_PASSENGER,
        UserProfile.ROLE_BOTH,
    ]


@login_required
def create_booking(request, trip_pk):
    if not user_can_book(request.user):
        messages.error(request, 'Оставлять заявки может только пользователь с ролью пассажира.')
        return redirect('profiles:profile_dashboard')

    today = timezone.localdate()

    trip = get_object_or_404(
        Trip,
        pk=trip_pk,
        status=Trip.STATUS_ACTIVE
    )

    if trip.driver == request.user:
        messages.error(
            request,
            'Нельзя оставить заявку на собственную поездку.'
        )
        return redirect('trips:trip_detail', pk=trip.pk)

    if trip.departure_date < today:
        messages.error(
            request,
            'Нельзя оставить заявку на прошедшую поездку.'
        )
        return redirect('trips:trip_detail', pk=trip.pk)

    if trip.seats_available <= 0:
        messages.error(
            request,
            'На эту поездку больше нет свободных мест.'
        )
        return redirect('trips:trip_detail', pk=trip.pk)

    active_booking_exists = Booking.objects.filter(
        trip=trip,
        passenger=request.user,
        status__in=[
            Booking.STATUS_NEW,
            Booking.STATUS_APPROVED,
        ]
    ).exists()

    if active_booking_exists:
        messages.error(
            request,
            'У вас уже есть активная заявка на эту поездку.'
        )
        return redirect('trips:trip_detail', pk=trip.pk)

    if request.method == 'POST':
        form = BookingForm(request.POST)

        if form.is_valid():
            seats_count = form.cleaned_data['seats_count']

            if seats_count > trip.seats_available:
                form.add_error(
                    'seats_count',
                    f'В поездке доступно мест: {trip.seats_available}.'
                )
            else:
                booking = form.save(commit=False)
                booking.trip = trip
                booking.passenger = request.user
                booking.save()

                return redirect('bookings:booking_success', pk=booking.pk)
    else:
        form = BookingForm(initial={
            'passenger_name': request.user.first_name or request.user.username,
        })

    context = {
        'trip': trip,
        'form': form,
    }

    return render(request, 'bookings/booking_form.html', context)


@login_required
def booking_success(request, pk):
    booking = get_object_or_404(Booking, pk=pk, passenger=request.user)

    context = {
        'booking': booking,
    }

    return render(request, 'bookings/booking_success.html', context)


@login_required
def trip_bookings(request, trip_pk):
    trip = get_object_or_404(Trip, pk=trip_pk, driver=request.user)
    bookings = Booking.objects.filter(trip=trip)

    context = {
        'trip': trip,
        'bookings': bookings,
        'bookings_count': bookings.count(),
    }

    return render(request, 'bookings/trip_bookings.html', context)


@login_required
def update_booking_status(request, trip_pk, booking_pk, status):
    trip = get_object_or_404(Trip, pk=trip_pk, driver=request.user)
    booking = get_object_or_404(Booking, pk=booking_pk, trip=trip)

    allowed_statuses = [
        Booking.STATUS_APPROVED,
        Booking.STATUS_REJECTED,
        Booking.STATUS_CANCELLED,
    ]

    if request.method == 'POST' and status in allowed_statuses:
        old_status = booking.status
        new_status = status

        if old_status == new_status:
            return redirect('bookings:trip_bookings', trip_pk=trip.pk)

        if new_status == Booking.STATUS_APPROVED:
            if old_status != Booking.STATUS_APPROVED:
                if booking.seats_count > trip.seats_available:
                    messages.error(
                        request,
                        'Недостаточно свободных мест для подтверждения заявки.'
                    )
                    return redirect('bookings:trip_bookings', trip_pk=trip.pk)

                trip.seats_available -= booking.seats_count
                trip.save()

        if old_status == Booking.STATUS_APPROVED and new_status != Booking.STATUS_APPROVED:
            trip.seats_available += booking.seats_count
            trip.save()

        booking.status = new_status
        booking.save()

        messages.success(request, 'Статус заявки обновлен.')

    return redirect('bookings:trip_bookings', trip_pk=trip.pk)


@login_required
def cancel_my_booking(request, pk):
    booking = get_object_or_404(
        Booking,
        pk=pk,
        passenger=request.user
    )

    if request.method == 'POST':
        if booking.status == Booking.STATUS_APPROVED:
            trip = booking.trip
            trip.seats_available += booking.seats_count
            trip.save()

        booking.status = Booking.STATUS_CANCELLED
        booking.save()

        messages.success(request, 'Заявка отменена.')

    return redirect('profiles:profile_dashboard')