from django.contrib import admin
from .models import Booking


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = (
        'passenger_name',
        'passenger',
        'passenger_phone',
        'trip',
        'seats_count',
        'status',
        'created_at',
    )
    list_filter = ('status', 'created_at')
    search_fields = (
        'passenger_name',
        'passenger_phone',
        'passenger__username',
        'passenger__first_name',
        'trip__from_city',
        'trip__to_city',
    )
    ordering = ('-created_at',)