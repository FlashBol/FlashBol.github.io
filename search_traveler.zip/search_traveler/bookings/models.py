from django.conf import settings
from django.db import models

from trips.models import Trip


class Booking(models.Model):
    STATUS_NEW = 'new'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'
    STATUS_CANCELLED = 'cancelled'

    STATUS_CHOICES = [
        (STATUS_NEW, 'Новая'),
        (STATUS_APPROVED, 'Подтверждена'),
        (STATUS_REJECTED, 'Отклонена'),
        (STATUS_CANCELLED, 'Отменена'),
    ]

    trip = models.ForeignKey(
        Trip,
        on_delete=models.CASCADE,
        related_name='bookings',
        verbose_name='Поездка'
    )
    passenger = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name='bookings',
        verbose_name='Пассажир',
        null=True,
        blank=True
    )
    passenger_name = models.CharField('Имя пассажира', max_length=120)
    passenger_phone = models.CharField('Телефон', max_length=30)
    seats_count = models.PositiveSmallIntegerField('Количество мест', default=1)
    comment = models.TextField('Комментарий', blank=True)
    status = models.CharField(
        'Статус',
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_NEW
    )
    created_at = models.DateTimeField('Дата заявки', auto_now_add=True)

    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.passenger_name} — {self.trip}'