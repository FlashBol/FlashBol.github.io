from django import forms
from .models import Booking


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['passenger_name', 'passenger_phone', 'seats_count', 'comment']

        widgets = {
            'passenger_name': forms.TextInput(attrs={
                'placeholder': 'Введите ваше имя',
            }),
            'passenger_phone': forms.TextInput(attrs={
                'placeholder': '+7 900 000-00-00',
            }),
            'seats_count': forms.NumberInput(attrs={
                'min': 1,
                'max': 8,
            }),
            'comment': forms.Textarea(attrs={
                'placeholder': 'Например: удобно встретиться у вокзала',
                'rows': 4,
            }),
        }

    def clean_seats_count(self):
        seats_count = self.cleaned_data.get('seats_count')

        if seats_count < 1:
            raise forms.ValidationError('Количество мест должно быть не меньше 1.')

        return seats_count