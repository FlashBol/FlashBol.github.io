document.addEventListener('DOMContentLoaded', function () {
    initFilterChips();
    initClearFiltersButton();
    initDangerConfirmations();
    initTextCounters();
    initPhoneMask();
});


function initFilterChips() {
    const filterForm = document.querySelector('[data-filter-form]');
    const chipsContainer = document.querySelector('[data-filter-chips]');

    if (!filterForm || !chipsContainer) {
        return;
    }

    const filterFields = [
        {
            name: 'from_city',
            label: 'Откуда'
        },
        {
            name: 'to_city',
            label: 'Куда'
        },
        {
            name: 'date',
            label: 'Дата'
        },
        {
            name: 'seats',
            label: 'От мест'
        },
        {
            name: 'max_price',
            label: 'До'
        }
    ];

    chipsContainer.innerHTML = '';

    let hasActiveFilters = false;

    filterFields.forEach(function (field) {
        const input = filterForm.querySelector('[name="' + field.name + '"]');

        if (!input || !input.value.trim()) {
            return;
        }

        hasActiveFilters = true;

        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'filter-chip';
        chip.dataset.fieldName = field.name;

        let valueText = input.value.trim();

        if (field.name === 'max_price') {
            valueText = valueText + ' ₽';
        }

        if (field.name === 'date') {
            valueText = formatDateValue(valueText);
        }

        chip.innerHTML = '<span>' + field.label + ': ' + valueText + '</span><strong>×</strong>';

        chip.addEventListener('click', function () {
            input.value = '';
            chip.remove();

            if (!chipsContainer.querySelector('.filter-chip')) {
                chipsContainer.classList.add('is-empty');
            }
        });

        chipsContainer.appendChild(chip);
    });

    if (hasActiveFilters) {
        chipsContainer.classList.remove('is-empty');
    } else {
        chipsContainer.classList.add('is-empty');
    }
}


function initClearFiltersButton() {
    const clearButton = document.querySelector('[data-clear-filters]');
    const filterForm = document.querySelector('[data-filter-form]');

    if (!clearButton || !filterForm) {
        return;
    }

    clearButton.addEventListener('click', function () {
        const fields = filterForm.querySelectorAll('input, select');

        fields.forEach(function (field) {
            if (field.name === 'sort') {
                field.value = 'nearest';
            } else {
                field.value = '';
            }
        });

        const chipsContainer = document.querySelector('[data-filter-chips]');

        if (chipsContainer) {
            chipsContainer.innerHTML = '';
            chipsContainer.classList.add('is-empty');
        }
    });
}


function initDangerConfirmations() {
    const dangerForms = document.querySelectorAll('[data-confirm]');

    if (!dangerForms.length) {
        return;
    }

    let activeForm = null;

    const modal = document.createElement('div');
    modal.className = 'confirm-modal';
    modal.innerHTML = `
        <div class="confirm-modal-backdrop" data-confirm-close></div>
        <div class="confirm-modal-card">
            <div class="confirm-modal-mark">!</div>
            <h2>Подтвердите действие</h2>
            <p data-confirm-text>Вы уверены, что хотите выполнить это действие?</p>
            <div class="confirm-modal-actions">
                <button type="button" class="confirm-cancel-btn" data-confirm-close>Отмена</button>
                <button type="button" class="confirm-accept-btn" data-confirm-accept>Подтвердить</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    const textElement = modal.querySelector('[data-confirm-text]');
    const acceptButton = modal.querySelector('[data-confirm-accept]');
    const closeButtons = modal.querySelectorAll('[data-confirm-close]');

    dangerForms.forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();

            activeForm = form;
            textElement.textContent = form.dataset.confirm || 'Вы уверены, что хотите выполнить это действие?';
            modal.classList.add('is-visible');
        });
    });

    acceptButton.addEventListener('click', function () {
        if (activeForm) {
            activeForm.removeAttribute('data-confirm');
            activeForm.submit();
        }
    });

    closeButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            activeForm = null;
            modal.classList.remove('is-visible');
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            activeForm = null;
            modal.classList.remove('is-visible');
        }
    });
}


function initTextCounters() {
    const fields = document.querySelectorAll('[data-max-length]');

    fields.forEach(function (field) {
        const maxLength = Number(field.dataset.maxLength);

        if (!maxLength) {
            return;
        }

        const counter = document.createElement('div');
        counter.className = 'text-counter';

        field.insertAdjacentElement('afterend', counter);

        const updateCounter = function () {
            const currentLength = field.value.length;
            counter.textContent = currentLength + ' / ' + maxLength + ' символов';

            if (currentLength > maxLength) {
                counter.classList.add('is-over-limit');
            } else {
                counter.classList.remove('is-over-limit');
            }
        };

        field.addEventListener('input', updateCounter);
        updateCounter();
    });
}


function initPhoneMask() {
    const phoneInputs = document.querySelectorAll('[data-phone-mask]');

    phoneInputs.forEach(function (input) {
        input.addEventListener('input', function () {
            input.value = formatRussianPhone(input.value);
        });

        input.addEventListener('focus', function () {
            if (!input.value.trim()) {
                input.value = '+7 ';
            }
        });

        input.addEventListener('blur', function () {
            if (input.value.trim() === '+7') {
                input.value = '';
            }
        });
    });
}


function formatRussianPhone(value) {
    let digits = value.replace(/\D/g, '');

    if (digits.startsWith('8')) {
        digits = '7' + digits.slice(1);
    }

    if (!digits.startsWith('7')) {
        digits = '7' + digits;
    }

    digits = digits.slice(0, 11);

    const part1 = digits.slice(1, 4);
    const part2 = digits.slice(4, 7);
    const part3 = digits.slice(7, 9);
    const part4 = digits.slice(9, 11);

    let result = '+7';

    if (part1) {
        result += ' ' + part1;
    }

    if (part2) {
        result += ' ' + part2;
    }

    if (part3) {
        result += '-' + part3;
    }

    if (part4) {
        result += '-' + part4;
    }

    return result;
}


function formatDateValue(value) {
    const parts = value.split('-');

    if (parts.length !== 3) {
        return value;
    }

    return parts[2] + '.' + parts[1] + '.' + parts[0];
}