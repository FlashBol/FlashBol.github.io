from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('trips/', include('trips.urls')),
    path('bookings/', include('bookings.urls')),
    path('profile/', include('profiles.urls')),
    path('accounts/', include('accounts.urls')),
]