from django.db.models import Count, Min
from django.shortcuts import render
from django.utils import timezone

from bookings.models import Booking
from trips.models import Trip


def home(request):
    today = timezone.localdate()

    active_trips = Trip.objects.filter(
        status=Trip.STATUS_ACTIVE,
        seats_available__gt=0,
        departure_date__gte=today,
    )

    active_trips_count = active_trips.count()

    directions_count = active_trips.values(
        'from_city',
        'to_city'
    ).distinct().count()

    bookings_count = Booking.objects.count()

    popular_routes = active_trips.values(
        'from_city',
        'to_city'
    ).annotate(
        trips_count=Count('id'),
        min_price=Min('price')
    ).order_by(
        '-trips_count',
        'min_price'
    )[:4]

    context = {
        'active_trips_count': active_trips_count,
        'directions_count': directions_count,
        'bookings_count': bookings_count,
        'popular_routes': popular_routes,
    }

    return render(request, 'core/home.html', context)