from datetime import timedelta, time

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from accounts.models import UserProfile
from bookings.models import Booking
from trips.models import Trip


class Command(BaseCommand):
    help = 'Создает демонстрационных пользователей, поездки и заявки для проверки сайта.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Удалить старые демонстрационные данные перед созданием новых.'
        )

    @transaction.atomic
    def handle(self, *args, **options):
        if options['clear']:
            self.clear_demo_data()

        users = self.create_users()
        trips = self.create_trips(users)
        self.create_bookings(users, trips)

        self.stdout.write(
            self.style.SUCCESS('Демонстрационные данные успешно созданы.')
        )

        self.print_login_data()

    def clear_demo_data(self):
        demo_usernames = [
            'driver1',
            'driver2',
            'passenger1',
            'passenger2',
            'both1',
        ]

        Booking.objects.filter(
            passenger__username__in=demo_usernames
        ).delete()

        Trip.objects.filter(
            driver__username__in=demo_usernames
        ).delete()

        User.objects.filter(
            username__in=demo_usernames
        ).delete()

        self.stdout.write(
            self.style.WARNING('Старые демонстрационные данные удалены.')
        )

    def create_users(self):
        users_data = [
            {
                'username': 'driver1',
                'first_name': 'Алексей',
                'role': UserProfile.ROLE_DRIVER,
            },
            {
                'username': 'driver2',
                'first_name': 'Марина',
                'role': UserProfile.ROLE_DRIVER,
            },
            {
                'username': 'passenger1',
                'first_name': 'Иван',
                'role': UserProfile.ROLE_PASSENGER,
            },
            {
                'username': 'passenger2',
                'first_name': 'Ольга',
                'role': UserProfile.ROLE_PASSENGER,
            },
            {
                'username': 'both1',
                'first_name': 'Дмитрий',
                'role': UserProfile.ROLE_BOTH,
            },
        ]

        users = {}

        for user_data in users_data:
            user, created = User.objects.get_or_create(
                username=user_data['username'],
                defaults={
                    'first_name': user_data['first_name'],
                    'is_active': True,
                }
            )

            user.first_name = user_data['first_name']
            user.set_password('password123')
            user.save()

            profile, profile_created = UserProfile.objects.get_or_create(
                user=user
            )
            profile.role = user_data['role']
            profile.save()

            users[user.username] = user

        return users

    def create_trips(self, users):
        today = timezone.localdate()

        trips_data = [
            {
                'driver': users['driver1'],
                'from_city': 'Москва',
                'to_city': 'Санкт-Петербург',
                'departure_date': today + timedelta(days=1),
                'departure_time': time(9, 30),
                'seats_available': 3,
                'price': 1500,
                'driver_name': 'Алексей',
                'car_model': 'Kia Rio',
                'meeting_place': 'Москва, метро Сокол',
                'description': 'Комфортная поездка без крупных остановок. Можно взять небольшой багаж.',
            },
            {
                'driver': users['driver1'],
                'from_city': 'Москва',
                'to_city': 'Казань',
                'departure_date': today + timedelta(days=2),
                'departure_time': time(7, 15),
                'seats_available': 2,
                'price': 1300,
                'driver_name': 'Алексей',
                'car_model': 'Kia Rio',
                'meeting_place': 'Москва, парковка у ТЦ',
                'description': 'Выезд утром, остановки по договоренности.',
            },
            {
                'driver': users['driver2'],
                'from_city': 'Краснодар',
                'to_city': 'Сочи',
                'departure_date': today + timedelta(days=1),
                'departure_time': time(11, 0),
                'seats_available': 4,
                'price': 900,
                'driver_name': 'Марина',
                'car_model': 'Hyundai Solaris',
                'meeting_place': 'Краснодар, автовокзал',
                'description': 'Поездка по основному маршруту, место для багажа ограничено.',
            },
            {
                'driver': users['driver2'],
                'from_city': 'Екатеринбург',
                'to_city': 'Челябинск',
                'departure_date': today + timedelta(days=3),
                'departure_time': time(14, 40),
                'seats_available': 1,
                'price': 600,
                'driver_name': 'Марина',
                'car_model': 'Hyundai Solaris',
                'meeting_place': 'Екатеринбург, ж/д вокзал',
                'description': 'Быстрая поездка без длительных остановок.',
            },
            {
                'driver': users['both1'],
                'from_city': 'Нижний Новгород',
                'to_city': 'Москва',
                'departure_date': today + timedelta(days=4),
                'departure_time': time(8, 0),
                'seats_available': 3,
                'price': 1100,
                'driver_name': 'Дмитрий',
                'car_model': 'Volkswagen Polo',
                'meeting_place': 'Нижний Новгород, площадь Ленина',
                'description': 'Удобный маршрут до Москвы, можно обсудить точку высадки.',
            },
            {
                'driver': users['both1'],
                'from_city': 'Москва',
                'to_city': 'Тула',
                'departure_date': today + timedelta(days=5),
                'departure_time': time(18, 20),
                'seats_available': 2,
                'price': 700,
                'driver_name': 'Дмитрий',
                'car_model': 'Volkswagen Polo',
                'meeting_place': 'Москва, метро Аннино',
                'description': 'Вечерний выезд, небольшие остановки по маршруту.',
            },
            {
                'driver': users['driver1'],
                'from_city': 'Москва',
                'to_city': 'Владимир',
                'departure_date': today + timedelta(days=6),
                'departure_time': time(10, 0),
                'seats_available': 5,
                'price': 800,
                'driver_name': 'Алексей',
                'car_model': 'Kia Rio',
                'meeting_place': 'Москва, метро Щелковская',
                'description': 'Подходит для пассажиров с небольшим багажом.',
            },
            {
                'driver': users['driver2'],
                'from_city': 'Сочи',
                'to_city': 'Краснодар',
                'departure_date': today - timedelta(days=2),
                'departure_time': time(12, 0),
                'seats_available': 2,
                'price': 850,
                'driver_name': 'Марина',
                'car_model': 'Hyundai Solaris',
                'meeting_place': 'Сочи, ж/д вокзал',
                'description': 'Прошедшая поездка для проверки завершенных маршрутов.',
            },
        ]

        trips = {}

        for index, trip_data in enumerate(trips_data, start=1):
            trip = Trip.objects.create(
                driver=trip_data['driver'],
                from_city=trip_data['from_city'],
                to_city=trip_data['to_city'],
                departure_date=trip_data['departure_date'],
                departure_time=trip_data['departure_time'],
                seats_available=trip_data['seats_available'],
                price=trip_data['price'],
                driver_name=trip_data['driver_name'],
                car_model=trip_data['car_model'],
                meeting_place=trip_data['meeting_place'],
                description=trip_data['description'],
                status=Trip.STATUS_ACTIVE,
            )

            trips[f'trip_{index}'] = trip

        return trips

    def create_bookings(self, users, trips):
        bookings_data = [
            {
                'trip': trips['trip_1'],
                'passenger': users['passenger1'],
                'passenger_name': 'Иван',
                'passenger_phone': '+7 900 111-11-11',
                'seats_count': 1,
                'comment': 'Удобно встретиться у метро.',
                'status': Booking.STATUS_NEW,
            },
            {
                'trip': trips['trip_1'],
                'passenger': users['passenger2'],
                'passenger_name': 'Ольга',
                'passenger_phone': '+7 900 222-22-22',
                'seats_count': 1,
                'comment': 'Буду с небольшой сумкой.',
                'status': Booking.STATUS_APPROVED,
            },
            {
                'trip': trips['trip_2'],
                'passenger': users['passenger1'],
                'passenger_name': 'Иван',
                'passenger_phone': '+7 900 111-11-11',
                'seats_count': 1,
                'comment': 'Подойдет любое место в машине.',
                'status': Booking.STATUS_REJECTED,
            },
            {
                'trip': trips['trip_3'],
                'passenger': users['both1'],
                'passenger_name': 'Дмитрий',
                'passenger_phone': '+7 900 333-33-33',
                'seats_count': 2,
                'comment': 'Едем вдвоем, без крупного багажа.',
                'status': Booking.STATUS_APPROVED,
            },
            {
                'trip': trips['trip_4'],
                'passenger': users['passenger2'],
                'passenger_name': 'Ольга',
                'passenger_phone': '+7 900 222-22-22',
                'seats_count': 1,
                'comment': 'Если можно, сяду на заднее место.',
                'status': Booking.STATUS_CANCELLED,
            },
            {
                'trip': trips['trip_5'],
                'passenger': users['passenger1'],
                'passenger_name': 'Иван',
                'passenger_phone': '+7 900 111-11-11',
                'seats_count': 1,
                'comment': 'Могу подойти к месту встречи заранее.',
                'status': Booking.STATUS_NEW,
            },
        ]

        for booking_data in bookings_data:
            trip = booking_data['trip']

            Booking.objects.create(
                trip=trip,
                passenger=booking_data['passenger'],
                passenger_name=booking_data['passenger_name'],
                passenger_phone=booking_data['passenger_phone'],
                seats_count=booking_data['seats_count'],
                comment=booking_data['comment'],
                status=booking_data['status'],
            )

            if booking_data['status'] == Booking.STATUS_APPROVED:
                trip.seats_available -= booking_data['seats_count']

                if trip.seats_available < 0:
                    trip.seats_available = 0

                trip.save()

    def print_login_data(self):
        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS('Данные для входа:'))
        self.stdout.write('driver1 / password123 — водитель')
        self.stdout.write('driver2 / password123 — водитель')
        self.stdout.write('passenger1 / password123 — пассажир')
        self.stdout.write('passenger2 / password123 — пассажир')
        self.stdout.write('both1 / password123 — водитель и пассажир')
        self.stdout.write('')
        self.stdout.write('Страницы для проверки:')
        self.stdout.write('http://127.0.0.1:8000/')
        self.stdout.write('http://127.0.0.1:8000/trips/')
        self.stdout.write('http://127.0.0.1:8000/profile/')
        self.stdout.write('http://127.0.0.1:8000/accounts/login/')