from django.conf import settings
from django.db import models


class Trip(models.Model):
    STATUS_ACTIVE = 'active'
    STATUS_COMPLETED = 'completed'
    STATUS_CANCELLED = 'cancelled'

    STATUS_CHOICES = [
        (STATUS_ACTIVE, 'Активна'),
        (STATUS_COMPLETED, 'Завершена'),
        (STATUS_CANCELLED, 'Отменена'),
    ]

    driver = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name='trips',
        verbose_name='Водитель',
        null=True,
        blank=True
    )
    from_city = models.CharField('Город отправления', max_length=120)
    to_city = models.CharField('Город назначения', max_length=120)
    departure_date = models.DateField('Дата отправления')
    departure_time = models.TimeField('Время отправления')
    seats_available = models.PositiveSmallIntegerField('Свободных мест')
    price = models.PositiveIntegerField('Стоимость поездки')
    driver_name = models.CharField('Имя водителя', max_length=120)
    car_model = models.CharField('Автомобиль', max_length=120, blank=True)
    meeting_place = models.CharField('Место встречи', max_length=255, blank=True)
    description = models.TextField('Описание поездки', blank=True)
    status = models.CharField(
        'Статус',
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_ACTIVE
    )
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)

    class Meta:
        verbose_name = 'Поездка'
        verbose_name_plural = 'Поездки'
        ordering = ['departure_date', 'departure_time']

    def __str__(self):
        return f'{self.from_city} — {self.to_city}, {self.departure_date}'