from django.urls import path
from . import views


app_name = 'trips'

urlpatterns = [
    path('', views.trip_list, name='trip_list'),
    path('create/', views.trip_create, name='trip_create'),
    path('create/success/<int:pk>/', views.trip_create_success, name='trip_create_success'),
    path('<int:pk>/edit/', views.trip_update, name='trip_update'),
    path('<int:pk>/cancel/', views.trip_cancel, name='trip_cancel'),
    path('<int:pk>/', views.trip_detail, name='trip_detail'),
]