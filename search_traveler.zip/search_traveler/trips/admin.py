from django.contrib import admin
from .models import Trip


@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = (
        'from_city',
        'to_city',
        'departure_date',
        'departure_time',
        'driver',
        'driver_name',
        'seats_available',
        'price',
        'status',
    )
    list_filter = ('status', 'departure_date', 'from_city', 'to_city')
    search_fields = (
        'from_city',
        'to_city',
        'driver__username',
        'driver__first_name',
        'driver_name',
        'car_model',
    )
    ordering = ('departure_date', 'departure_time')