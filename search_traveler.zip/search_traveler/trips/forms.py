from django import forms
from django.utils import timezone

from .models import Trip


class TripForm(forms.ModelForm):
    class Meta:
        model = Trip
        fields = [
            'from_city',
            'to_city',
            'departure_date',
            'departure_time',
            'seats_available',
            'price',
            'driver_name',
            'car_model',
            'meeting_place',
            'description',
        ]

        widgets = {
            'from_city': forms.TextInput(attrs={
                'placeholder': 'Например: Москва',
            }),
            'to_city': forms.TextInput(attrs={
                'placeholder': 'Например: Санкт-Петербург',
            }),
            'departure_date': forms.DateInput(attrs={
                'type': 'date',
            }),
            'departure_time': forms.TimeInput(attrs={
                'type': 'time',
            }),
            'seats_available': forms.NumberInput(attrs={
                'min': 1,
                'max': 8,
            }),
            'price': forms.NumberInput(attrs={
                'min': 0,
                'placeholder': 'Например: 1500',
            }),
            'driver_name': forms.TextInput(attrs={
                'placeholder': 'Введите имя водителя',
            }),
            'car_model': forms.TextInput(attrs={
                'placeholder': 'Например: Kia Rio',
            }),
            'meeting_place': forms.TextInput(attrs={
                'placeholder': 'Например: парковка у вокзала',
            }),
            'description': forms.Textarea(attrs={
                'placeholder': 'Дополнительная информация о поездке',
                'rows': 4,
            }),
        }

    def clean_departure_date(self):
        departure_date = self.cleaned_data.get('departure_date')
        today = timezone.localdate()

        if departure_date and departure_date < today:
            raise forms.ValidationError('Нельзя создать поездку на прошедшую дату.')

        return departure_date

    def clean_seats_available(self):
        seats_available = self.cleaned_data.get('seats_available')

        if seats_available < 1:
            raise forms.ValidationError('Количество свободных мест должно быть не меньше 1.')

        if seats_available > 8:
            raise forms.ValidationError('Количество свободных мест не должно быть больше 8.')

        return seats_available

    def clean_price(self):
        price = self.cleaned_data.get('price')

        if price < 0:
            raise forms.ValidationError('Стоимость поездки не может быть отрицательной.')

        return price