from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone

from accounts.models import UserProfile
from bookings.models import Booking
from .models import Trip
from .forms import TripForm


def user_can_drive(user):
    profile, created = UserProfile.objects.get_or_create(user=user)
    return profile.role in [
        UserProfile.ROLE_DRIVER,
        UserProfile.ROLE_BOTH,
    ]


def trip_list(request):
    today = timezone.localdate()

    trips = Trip.objects.filter(
        status=Trip.STATUS_ACTIVE,
        seats_available__gt=0,
        departure_date__gte=today,
    )

    from_city = request.GET.get('from_city', '').strip()
    to_city = request.GET.get('to_city', '').strip()
    date = request.GET.get('date', '').strip()
    seats = request.GET.get('seats', '').strip()
    max_price = request.GET.get('max_price', '').strip()
    sort = request.GET.get('sort', 'nearest').strip()

    if from_city:
        trips = trips.filter(from_city__icontains=from_city)

    if to_city:
        trips = trips.filter(to_city__icontains=to_city)

    if date:
        trips = trips.filter(departure_date=date)

    if seats:
        trips = trips.filter(seats_available__gte=seats)

    if max_price:
        trips = trips.filter(price__lte=max_price)

    if sort == 'price_asc':
        trips = trips.order_by('price', 'departure_date', 'departure_time')
    elif sort == 'price_desc':
        trips = trips.order_by('-price', 'departure_date', 'departure_time')
    elif sort == 'seats_desc':
        trips = trips.order_by('-seats_available', 'departure_date', 'departure_time')
    else:
        trips = trips.order_by('departure_date', 'departure_time', 'price')

    context = {
        'trips': trips,
        'from_city': from_city,
        'to_city': to_city,
        'date': date,
        'seats': seats,
        'max_price': max_price,
        'sort': sort,
        'trips_count': trips.count(),
    }

    return render(request, 'trips/trip_list.html', context)


def trip_detail(request, pk):
    today = timezone.localdate()

    trip = get_object_or_404(
        Trip,
        pk=pk,
        status=Trip.STATUS_ACTIVE
    )

    is_trip_finished = trip.departure_date < today
    is_trip_owner = request.user.is_authenticated and trip.driver == request.user

    has_active_booking = False
    user_booking = None

    if request.user.is_authenticated:
        user_booking = Booking.objects.filter(
            trip=trip,
            passenger=request.user,
            status__in=[
                Booking.STATUS_NEW,
                Booking.STATUS_APPROVED,
            ]
        ).first()

        has_active_booking = user_booking is not None

    context = {
        'trip': trip,
        'is_trip_finished': is_trip_finished,
        'is_trip_owner': is_trip_owner,
        'has_active_booking': has_active_booking,
        'user_booking': user_booking,
    }

    return render(request, 'trips/trip_detail.html', context)


@login_required
def trip_create(request):
    if not user_can_drive(request.user):
        messages.error(request, 'Создавать поездки может только пользователь с ролью водителя.')
        return redirect('profiles:profile_dashboard')

    if request.method == 'POST':
        form = TripForm(request.POST)

        if form.is_valid():
            trip = form.save(commit=False)
            trip.driver = request.user
            trip.status = Trip.STATUS_ACTIVE
            trip.save()

            return redirect('trips:trip_create_success', pk=trip.pk)
    else:
        form = TripForm(initial={
            'driver_name': request.user.first_name or request.user.username,
        })

    context = {
        'form': form,
    }

    return render(request, 'trips/trip_create.html', context)


@login_required
def trip_create_success(request, pk):
    trip = get_object_or_404(Trip, pk=pk, driver=request.user)

    context = {
        'trip': trip,
    }

    return render(request, 'trips/trip_create_success.html', context)


@login_required
def trip_update(request, pk):
    if not user_can_drive(request.user):
        messages.error(request, 'Редактировать поездки может только пользователь с ролью водителя.')
        return redirect('profiles:profile_dashboard')

    trip = get_object_or_404(
        Trip,
        pk=pk,
        driver=request.user,
        status=Trip.STATUS_ACTIVE
    )

    if request.method == 'POST':
        form = TripForm(request.POST, instance=trip)

        if form.is_valid():
            form.save()
            messages.success(request, 'Поездка успешно обновлена.')

            return redirect('trips:trip_detail', pk=trip.pk)
    else:
        form = TripForm(instance=trip)

    context = {
        'form': form,
        'trip': trip,
    }

    return render(request, 'trips/trip_update.html', context)


@login_required
def trip_cancel(request, pk):
    if not user_can_drive(request.user):
        messages.error(request, 'Отменять поездки может только пользователь с ролью водителя.')
        return redirect('profiles:profile_dashboard')

    trip = get_object_or_404(
        Trip,
        pk=pk,
        driver=request.user,
        status=Trip.STATUS_ACTIVE
    )

    if request.method == 'POST':
        trip.status = Trip.STATUS_CANCELLED
        trip.save()

        messages.success(request, 'Поездка отменена и больше не отображается в поиске.')

    return redirect('profiles:profile_dashboard')