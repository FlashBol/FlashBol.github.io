from django.urls import path
from . import views


app_name = 'profiles'

urlpatterns = [
    path('', views.profile_dashboard, name='profile_dashboard'),
    path('drivers/<int:pk>/', views.driver_public_profile, name='driver_public_profile'),
]