from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.utils import timezone

from accounts.models import UserProfile
from bookings.models import Booking
from trips.models import Trip


@login_required
def profile_dashboard(request):
    today = timezone.localdate()

    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    my_trips = Trip.objects.filter(driver=request.user)
    active_trips = my_trips.filter(
        status=Trip.STATUS_ACTIVE,
        departure_date__gte=today,
    )
    available_trips = active_trips.filter(seats_available__gt=0)
    completed_trips = my_trips.filter(departure_date__lt=today)

    bookings_for_my_trips = Booking.objects.select_related('trip', 'passenger').filter(
        trip__driver=request.user,
        trip__status=Trip.STATUS_ACTIVE,
    )

    my_passenger_bookings = Booking.objects.select_related('trip').filter(
        passenger=request.user
    )

    new_bookings = bookings_for_my_trips.filter(status=Booking.STATUS_NEW)
    approved_bookings = bookings_for_my_trips.filter(status=Booking.STATUS_APPROVED)

    recent_trips = active_trips.order_by('-created_at')[:5]
    recent_bookings = bookings_for_my_trips.order_by('-created_at')[:5]
    my_recent_passenger_bookings = my_passenger_bookings.order_by('-created_at')[:5]

    can_drive = user_profile.role in [
        UserProfile.ROLE_DRIVER,
        UserProfile.ROLE_BOTH,
    ]
    can_book = user_profile.role in [
        UserProfile.ROLE_PASSENGER,
        UserProfile.ROLE_BOTH,
    ]

    context = {
        'user_profile': user_profile,
        'can_drive': can_drive,
        'can_book': can_book,
        'active_trips_count': active_trips.count(),
        'available_trips_count': available_trips.count(),
        'completed_trips_count': completed_trips.count(),
        'new_bookings_count': new_bookings.count(),
        'approved_bookings_count': approved_bookings.count(),
        'recent_trips': recent_trips,
        'recent_bookings': recent_bookings,
        'my_recent_passenger_bookings': my_recent_passenger_bookings,
    }

    return render(request, 'profiles/profile_dashboard.html', context)


def driver_public_profile(request, pk):
    today = timezone.localdate()

    driver_profile = UserProfile.objects.select_related('user').get(pk=pk)
    driver = driver_profile.user

    active_trips = Trip.objects.filter(
        driver=driver,
        status=Trip.STATUS_ACTIVE,
        departure_date__gte=today,
    )

    available_trips = active_trips.filter(seats_available__gt=0)
    completed_trips_count = Trip.objects.filter(
        driver=driver,
        departure_date__lt=today,
    ).count()

    context = {
        'driver_profile': driver_profile,
        'driver': driver,
        'active_trips': active_trips,
        'active_trips_count': active_trips.count(),
        'available_trips_count': available_trips.count(),
        'completed_trips_count': completed_trips_count,
    }

    return render(request, 'profiles/driver_public_profile.html', context)