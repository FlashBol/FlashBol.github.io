from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User

from .models import UserProfile


class RegisterForm(UserCreationForm):
    first_name = forms.CharField(
        label='Имя',
        max_length=120,
        widget=forms.TextInput(attrs={
            'placeholder': 'Введите имя',
        })
    )

    username = forms.CharField(
        label='Логин',
        max_length=150,
        widget=forms.TextInput(attrs={
            'placeholder': 'Придумайте логин',
        })
    )

    role = forms.ChoiceField(
        label='Роль в сервисе',
        choices=UserProfile.ROLE_CHOICES,
        widget=forms.Select()
    )

    password1 = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Введите пароль',
        })
    )

    password2 = forms.CharField(
        label='Подтверждение пароля',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Повторите пароль',
        })
    )

    class Meta:
        model = User
        fields = ['first_name', 'username', 'role', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=commit)

        if commit:
            profile, created = UserProfile.objects.get_or_create(user=user)
            profile.role = self.cleaned_data['role']
            profile.save()

        return user


class LoginForm(AuthenticationForm):
    username = forms.CharField(
        label='Логин',
        widget=forms.TextInput(attrs={
            'placeholder': 'Введите логин',
        })
    )

    password = forms.CharField(
        label='Пароль',
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Введите пароль',
        })
    )