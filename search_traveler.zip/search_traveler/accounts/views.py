from django.contrib.auth import login, logout
from django.shortcuts import render, redirect

from .forms import RegisterForm, LoginForm
from .models import UserProfile


def register_view(request):
    if request.user.is_authenticated:
        return redirect('profiles:profile_dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if form.is_valid():
            user = form.save()
            login(request, user)

            return redirect('profiles:profile_dashboard')
    else:
        form = RegisterForm()

    context = {
        'form': form,
    }

    return render(request, 'accounts/register.html', context)


def login_view(request):
    if request.user.is_authenticated:
        UserProfile.objects.get_or_create(user=request.user)
        return redirect('profiles:profile_dashboard')

    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)

        if form.is_valid():
            user = form.get_user()
            UserProfile.objects.get_or_create(user=user)
            login(request, user)

            return redirect('profiles:profile_dashboard')
    else:
        form = LoginForm()

    context = {
        'form': form,
    }

    return render(request, 'accounts/login.html', context)


def logout_view(request):
    logout(request)
    return redirect('core:home')