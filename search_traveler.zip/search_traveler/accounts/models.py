from django.conf import settings
from django.db import models


class UserProfile(models.Model):
    ROLE_PASSENGER = 'passenger'
    ROLE_DRIVER = 'driver'
    ROLE_BOTH = 'both'

    ROLE_CHOICES = [
        (ROLE_PASSENGER, 'Пассажир'),
        (ROLE_DRIVER, 'Водитель'),
        (ROLE_BOTH, 'Водитель и пассажир'),
    ]

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='profile',
        verbose_name='Пользователь'
    )
    role = models.CharField(
        'Роль',
        max_length=20,
        choices=ROLE_CHOICES,
        default=ROLE_PASSENGER
    )

    class Meta:
        verbose_name = 'Профиль пользователя'
        verbose_name_plural = 'Профили пользователей'

    def __str__(self):
        return f'{self.user.username} — {self.get_role_display()}'